
<?php
include("conexao.class.php"); 
$objetoConexao = new Conexao();
$connpdo = $objetoConexao->conectar();

if (getenv("REQUEST_METHOD") == "POST") {
	$col = "";
	$lin = "";
	$query = $_POST['query'];
	//simular query
	//$query = "select * from cadastro";
	$yes = stripos($query, 'select');
	if ($yes !== false) {
		$array = array();
		$stmt = $connpdo->query($query);
		$resultado = $stmt->fetchall();
		$cnt = count($resultado);
		if (!empty($resultado)) {
			$colunas = array_keys($resultado[0]);
			$colunasPares = array_filter($colunas, function ($key) {
				return $key % 2 == 0;
			}, ARRAY_FILTER_USE_KEY);
			
			
			foreach ($colunasPares as $coluna) {
				$col = $coluna." ".$col;
			}
			
			
			foreach ($resultado as $linha) {
				
				foreach ($colunasPares as $coluna) {
					$lin = $linha[$coluna]."#".$lin;
				}
				$lin = ")&(".$lin;
			}
			
			$lin = $lin.")";
			$lin = substr($lin,2);

			echo $lin;
		} else {
			
		}
	} else {
		
		try {
			$connpdo->exec($query);
			echo $query;
		} catch (PDOException $e) {
			echo "Erro: " . $e->getMessage();
		}
	}
}
?>	