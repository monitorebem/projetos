<?php
class Conexao{
	private $usuario;
	private $senha;
	private $banco;
	private $servidor;
	private static $conn;
		public function __construct(){
			$this->servidor = "localhost";
			$this->banco = "id21372046_jobzap";
			$this->usuario = "id21372046_root";
			$this->senha = "Jesus@2023";
		}
		public function conectar(){
			try{
				$conn = new PDO("mysql:host=".$this->servidor.";dbname=".$this->banco, $this->usuario, $this->senha);
				$conn->exec("set names utf8");
				$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				return $conn;
			}catch(PDOException $e){
				echo 'Error: '.$e->getMessage();
			}
		}
		public function __destruct(){
			
		}	
}
class Sessao{
	
	private $matricula;
	
		public function __construct(){
			session_start();
		}

		public function iniciarSessao($matricula){
			$_SESSION['matricula'] = $matricula;
		}

		public function encerrarSessao(){
			session_unset();
			session_destroy();
		}

		public function validarSessao(){
			if(!isset($_SESSION['matricula'])){
				header('Location: index.php');
				exit();
			}
		}
}	
?>
