-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 03/11/2023 às 23:14
-- Versão do servidor: 10.5.20-MariaDB
-- Versão do PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `id21372046_jobzap`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `atividade`
--

CREATE TABLE `atividade` (
  `id` int(11) NOT NULL,
  `info` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `atividade`
--

INSERT INTO `atividade` (`id`, `info`) VALUES
(1, 'Fazer Amizades'),
(2, 'Suporte Juridico'),
(3, 'Atendimento Médico'),
(4, 'Professor de Matemática'),
(5, 'Professor de Fisica'),
(6, 'Professor de Português'),
(7, 'Professor de História'),
(8, 'Aconselhamento espiritual'),
(9, 'CVV - Valorizando sua Vida'),
(10, 'Faz Tudo-Marido de Aluguel'),
(11, 'Administração de empresas'),
(12, 'Aconselhamento Financeiro'),
(13, 'Aconselhamento Familiar');

-- --------------------------------------------------------

--
-- Estrutura para tabela `cadastro`
--

CREATE TABLE `cadastro` (
  `id` int(10) NOT NULL,
  `foto` longtext DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `fone` varchar(40) DEFAULT NULL,
  `tipo` varchar(200) DEFAULT NULL,
  `atividade` varchar(200) DEFAULT NULL,
  `descricao` longtext DEFAULT NULL,
  `termo` varchar(10) DEFAULT NULL,
  `datahora` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `cadastro`
--

INSERT INTO `cadastro` (`id`, `foto`, `nome`, `fone`, `tipo`, `atividade`, `descricao`, `termo`, `datahora`) VALUES
(1, 'https://monitorebem.000webhostapp.com/83999061916.jpg', 'Yvna Millena', '83999061916', 'Filantrópico Online', 'Aulas de Matemática', 'teste de cadastro de dados', 'true', '2023-11-02 03:37:03'),
(4, 'https://monitorebem.000webhostapp.com/83998093096.jpg', 'Targino soares', '83998093096', 'Filantrópico Online', 'Fazer Amizades', 'novas amizades é sempre bom', 'true', '2023-11-03 07:25:47'),
(5, 'https://monitorebem.000webhostapp.com/.jpg', 'Adriana santos', '83986697145', 'Filantrópico Online', 'Aconselhamento Familiar', 'posso auxiliar nasatiidadesfamiliar', 'true', '2023-11-02 23:28:11');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `atividade`
--
ALTER TABLE `atividade`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cadastro`
--
ALTER TABLE `cadastro`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `atividade`
--
ALTER TABLE `atividade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `cadastro`
--
ALTER TABLE `cadastro`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
